package com.boot.project.model;

public enum Role {
    USER, ADMIN,MANAGER,CHEF,EMPLOYEE
}


