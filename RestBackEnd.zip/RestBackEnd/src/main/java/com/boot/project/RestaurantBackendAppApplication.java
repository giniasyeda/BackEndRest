package com.boot.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantBackendAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantBackendAppApplication.class, args);
	}

}
