package com.boot.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.boot.project.model.Inventory;
import com.boot.project.repository.InventoryRepository;

@Service
@Transactional
public class InventoryServiceImpl implements InventoryService {
	
	
	 @Autowired
	    private InventoryRepository inventoryRepository;

	@Override
	public Inventory saveInventory(Inventory inventory) {
		 inventoryRepository.save(inventory);
		return inventory;
	}

	@Override
	public Inventory updateInventory(Inventory inventory) {
		return inventoryRepository.save(inventory);
		
	}

	@Override
	public void deleteInventory(Long inventoryId) {
		inventoryRepository.deleteById(inventoryId);
		
	}

	@Override
	public Long numberOfInventories() {
		return inventoryRepository.count();
	}

	@Override
	public List<Inventory> findAllInventories() {
		return inventoryRepository.findAll();
	}

	
	   
}



